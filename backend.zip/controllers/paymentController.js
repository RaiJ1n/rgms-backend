const Payment = require('../models/Payment');
const MembershipPlan = require('../models/MembershipPlan');
const emailService = require('../services/emailService');
const generateReceiptNumber = require('../utils/generateReceiptNumber');

const httpError = (message, statusCode) => {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
};

const submitPayment = async (req, res, next) => {
  try {
    const { referenceNumber, paymentMethod, planId } = req.body;
    const screenshot = req.file ? req.file.path : undefined;

    // Reject a reference number that's already been submitted (pending,
    // approved, or rejected) under the same payment method — prevents a
    // single real transaction being used to spin up multiple Payment
    // records, which an admin could accidentally approve more than once.
    // This route's own validator (paymentRoutes.js) still requires
    // referenceNumber for every member-submitted payment, so this check
    // stays exactly as strict as before — it's unaffected by
    // referenceNumber becoming optional at the schema level, since that
    // relaxation was for admin-recorded cash payments, which never reach
    // this controller at all (see adminController.createManualPayment).
    const existing = await Payment.findOne({ referenceNumber, paymentMethod });
    if (existing) {
      throw httpError('This reference number has already been submitted', 400);
    }

    let amount = req.body.amount;
    if (planId) {
      const plan = await MembershipPlan.findById(planId);
      if (!plan) throw httpError('Plan not found', 404);
      amount = req.user.studentPromoActive && plan.studentPrice ? plan.studentPrice : plan.price;
    } else if (!amount) {
      throw httpError('Amount is required when no plan is specified', 400);
    }

    // Accidental double submission: a second PENDING payment for the same
    // plan would, once both are approved, stack two memberships. A genuine
    // renewal is still allowed — just not while an identical request is
    // still waiting for the front desk.
    if (planId) {
      const pendingSamePlan = await Payment.findOne({ userId: req.user._id, planId, status: 'pending' });
      if (pendingSamePlan) {
        throw httpError('You already have a pending payment for this membership. Please wait for it to be reviewed.', 409);
      }
    }

    const payment = await Payment.create({
      userId: req.user._id,
      planId: planId || undefined,
      referenceNumber,
      transactionNumber: generateReceiptNumber(),
      paymentMethod,
      amount,
      screenshot,
      status: 'pending',
    });

    res.status(201).json({ success: true, message: 'Payment submitted', data: payment });
  } catch (error) {
    next(error);
  }
};

const getPaymentHistory = async (req, res, next) => {
  try {
    const payments = await Payment.find({ userId: req.user._id });
    res.json({ success: true, data: payments });
  } catch (error) {
    next(error);
  }
};

module.exports = { submitPayment, getPaymentHistory };